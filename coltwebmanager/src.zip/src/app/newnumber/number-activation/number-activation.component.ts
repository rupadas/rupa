import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-number-activation',
  templateUrl: './number-activation.component.html',
  styleUrls: ['./number-activation.component.css']
})
export class NumberActivationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
