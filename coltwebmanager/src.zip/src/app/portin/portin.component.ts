import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portin',
  templateUrl: './portin.component.html',
  styleUrls: ['./portin.component.css']
})
export class PortinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
