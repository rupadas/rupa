import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortinComponent } from './portin.component';

describe('PortinComponent', () => {
  let component: PortinComponent;
  let fixture: ComponentFixture<PortinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
