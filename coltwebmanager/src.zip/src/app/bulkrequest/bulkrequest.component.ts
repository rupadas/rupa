import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bulkrequest',
  templateUrl: './bulkrequest.component.html',
  styleUrls: ['./bulkrequest.component.css']
})
export class BulkrequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
