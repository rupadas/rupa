import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portout',
  templateUrl: './portout.component.html',
  styleUrls: ['./portout.component.css']
})
export class PortoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
