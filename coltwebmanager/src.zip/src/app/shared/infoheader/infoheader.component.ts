import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-header',
  templateUrl: './infoheader.component.html',
  styleUrls: ['./infoheader.component.css']
})

export class InfoHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
