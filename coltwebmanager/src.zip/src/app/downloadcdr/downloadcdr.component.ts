import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadcdr',
  templateUrl: './downloadcdr.component.html',
  styleUrls: ['./downloadcdr.component.css']
})
export class DownloadcdrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
