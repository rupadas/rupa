import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})

export class WelcomeService extends BaseService {

	
	constructor(private http: HttpClient) { 
		super();
	}

	/*Get all domains details*/
	getDomains() {
		return this.http.get(this.baseUrl+`all`);
	}

	/*get all countries*/
	getCountries() {
		return this.http.get(this.baseUrl+`all`);
	}

	/*get profiles*/
	getServiceProfiles() {
		return this.http.get(this.baseUrl+`all`);
	}
}
